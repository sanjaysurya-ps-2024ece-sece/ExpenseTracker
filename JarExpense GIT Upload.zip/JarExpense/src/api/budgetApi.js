import api from "./api";

export const getBudgets = () => {
  return api.get("/budgets");
};

export const getBudgetById = (id) => {
  return api.get(`/budgets/${id}`);
};

export const createBudget = (budget) => {
  return api.post("/budgets", budget);
};