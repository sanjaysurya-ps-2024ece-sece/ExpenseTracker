import api from "./api";

export const getExpenses = () => {
    return api.get("/expenses");
};

export const getExpenseById = (id) => {
    return api.get(`/expenses/${id}`);
};

export const createExpense = (expense) => {
    return api.post("/expenses", expense);
};

export const deleteExpense = (id) => {
    return api.delete(`/expenses/${id}`);
};

export const getMonthlySpending = (
    userId,
    categoryId,
    startDate,
    endDate
) => {
    return api.get("/expenses/monthly", {
        params: {
            userId,
            categoryId,
            startDate,
            endDate,
        },
    });
};