import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import userApi from '../api/userApi';
import categoryApi from '../api/categoryApi';
import expenseApi from '../api/expenseApi';
import budgetApi from '../api/budgetApi';

const AppContext = createContext(null);

export const AppProvider = ({ children }) => {
  const [users, setUsers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [budgets, setBudgets] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState('');
  
  // Default to September 2026 (or current date if after)
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(now.getFullYear() === 2026 ? now.getMonth() + 1 : 9);
  const [selectedYear, setSelectedYear] = useState(now.getFullYear() === 2026 ? now.getFullYear() : 2026);
  
  const [loading, setLoading] = useState(true);
  const [serverError, setServerError] = useState(null);
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [isCreateBudgetOpen, setIsCreateBudgetOpen] = useState(false);
  const [isCreateCategoryOpen, setIsCreateCategoryOpen] = useState(false);
  const [isCreateUserOpen, setIsCreateUserOpen] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setServerError(null);
    try {
      const [usersRes, categoriesRes, expensesRes, budgetsRes] = await Promise.all([
        userApi.getAllUsers().catch((err) => {
          console.warn('Failed to fetch users:', err);
          return [];
        }),
        categoryApi.getAllCategories().catch((err) => {
          console.warn('Failed to fetch categories:', err);
          return [];
        }),
        expenseApi.getAllExpenses().catch((err) => {
          console.warn('Failed to fetch expenses:', err);
          return [];
        }),
        budgetApi.getAllBudgets().catch((err) => {
          console.warn('Failed to fetch budgets:', err);
          return [];
        }),
      ]);

      setUsers(usersRes || []);
      setCategories(categoriesRes || []);
      setExpenses(expensesRes || []);
      setBudgets(budgetsRes || []);

      // If no selected user and users are returned, default to first user or all
      if (!selectedUserId && usersRes && usersRes.length > 0) {
        setSelectedUserId(usersRes[0].id.toString());
      }
    } catch (err) {
      console.error('Error connecting to backend:', err);
      setServerError('Unable to connect to ExpenseJar server.');
    } finally {
      setLoading(false);
    }
  }, [selectedUserId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const activeUser = useMemo(() => {
    if (!selectedUserId || selectedUserId === 'all') return null;
    return users.find((u) => u.id === Number(selectedUserId)) || null;
  }, [users, selectedUserId]);

  const formatCurrency = useCallback((amount) => {
    const val = Number(amount) || 0;
    return `₹${val.toLocaleString('en-IN', {
      minimumFractionDigits: val % 1 !== 0 ? 2 : 0,
      maximumFractionDigits: 2,
    })}`;
  }, []);

  // Compute category spending for the current month/year
  const monthlyCategorySpending = useMemo(() => {
    const map = {};
    expenses.forEach((expense) => {
      if (!expense.date) return;
      const [year, month] = expense.date.split('-').map(Number);
      if (year === Number(selectedYear) && month === Number(selectedMonth)) {
        if (!selectedUserId || selectedUserId === 'all' || (expense.user && expense.user.id === Number(selectedUserId))) {
          const catId = expense.category?.id;
          if (catId) {
            map[catId] = (map[catId] || 0) + (Number(expense.amount) || 0);
          }
        }
      }
    });
    return map;
  }, [expenses, selectedMonth, selectedYear, selectedUserId]);

  // Compute budget alerts
  const budgetAlerts = useMemo(() => {
    const alerts = [];
    budgets.forEach((budget) => {
      if (budget.month === Number(selectedMonth) && budget.year === Number(selectedYear)) {
        if (!selectedUserId || selectedUserId === 'all' || (budget.user && budget.user.id === Number(selectedUserId))) {
          const spent = monthlyCategorySpending[budget.category?.id] || 0;
          const limit = Number(budget.amount) || 0;
          if (limit > 0) {
            const percentage = (spent / limit) * 100;
            const categoryName = budget.category?.name || 'Category';
            if (percentage > 100) {
              alerts.push({
                budgetId: budget.id,
                categoryName,
                spent,
                limit,
                percentage: Math.round(percentage),
                status: 'danger',
                message: `Budget exceeded for ${categoryName}! Spent ${formatCurrency(spent)} of ${formatCurrency(limit)}.`,
              });
            } else if (percentage >= 90) {
              alerts.push({
                budgetId: budget.id,
                categoryName,
                spent,
                limit,
                percentage: Math.round(percentage),
                status: 'warning',
                message: `Budget alert: you've reached ${Math.round(percentage)}% of your ${categoryName} budget.`,
              });
            }
          }
        }
      }
    });
    return alerts;
  }, [budgets, monthlyCategorySpending, selectedMonth, selectedYear, selectedUserId, formatCurrency]);

  const value = {
    users,
    categories,
    expenses,
    budgets,
    selectedUserId,
    setSelectedUserId,
    activeUser,
    selectedMonth,
    setSelectedMonth,
    selectedYear,
    setSelectedYear,
    monthlyCategorySpending,
    budgetAlerts,
    loading,
    serverError,
    fetchData,
    formatCurrency,
    isAddExpenseOpen,
    setIsAddExpenseOpen,
    isCreateBudgetOpen,
    setIsCreateBudgetOpen,
    isCreateCategoryOpen,
    setIsCreateCategoryOpen,
    isCreateUserOpen,
    setIsCreateUserOpen,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

export default AppContext;
