package com.example.JarExpense.expense;

import com.example.JarExpense.budget.BudgetService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ExpenseServiceTest {

    @Mock
    private ExpenseRepository expenseRepository;

    @Mock
    private BudgetService budgetService;

    @InjectMocks
    private ExpenseService expenseService;

    @Test
    void testGetMonthlySpendingSeptember() {
        Long userId = 1L;
        Long categoryId = 2L;
        Integer month = 9;
        Integer year = 2026;

        LocalDate expectedStart = LocalDate.of(2026, 9, 1);
        LocalDate expectedEnd = LocalDate.of(2026, 9, 30);

        when(expenseRepository.findTotalAmountByUserIdAndCategoryIdAndDateBetween(
                userId, categoryId, expectedStart, expectedEnd
        )).thenReturn(450.0);

        Double total = expenseService.getMonthlySpending(userId, categoryId, month, year);

        assertEquals(450.0, total);
        verify(expenseRepository).findTotalAmountByUserIdAndCategoryIdAndDateBetween(
                userId, categoryId, expectedStart, expectedEnd
        );
    }

    @Test
    void testGetMonthlySpendingOctober() {
        Long userId = 1L;
        Long categoryId = 2L;
        Integer month = 10;
        Integer year = 2026;

        LocalDate expectedStart = LocalDate.of(2026, 10, 1);
        LocalDate expectedEnd = LocalDate.of(2026, 10, 31);

        when(expenseRepository.findTotalAmountByUserIdAndCategoryIdAndDateBetween(
                userId, categoryId, expectedStart, expectedEnd
        )).thenReturn(750.0);

        Double total = expenseService.getMonthlySpending(userId, categoryId, month, year);

        assertEquals(750.0, total);
        verify(expenseRepository).findTotalAmountByUserIdAndCategoryIdAndDateBetween(
                userId, categoryId, expectedStart, expectedEnd
        );
    }
}
