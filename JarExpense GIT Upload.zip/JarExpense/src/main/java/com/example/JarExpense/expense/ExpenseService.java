package com.example.JarExpense.expense;

import com.example.JarExpense.budget.Budget;
import com.example.JarExpense.budget.BudgetService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ExpenseService {

    private final ExpenseRepository expenseRepository;
    private final BudgetService budgetService;

    public ExpenseService(
            ExpenseRepository expenseRepository,
            BudgetService budgetService) {

        this.expenseRepository = expenseRepository;
        this.budgetService = budgetService;
    }

    public Expense createExpense(Expense expense) {

        if (expense.getAmount() == null || expense.getAmount() <= 0) {
            throw new RuntimeException(
                    "Expense amount must be greater than 0"
            );
        }

        Expense savedExpense = expenseRepository.save(expense);

        checkBudgetAlert(savedExpense);

        return savedExpense;
    }

    public List<Expense> getAllExpenses() {
        return expenseRepository.findAll();
    }

    public Expense getExpenseById(Long id) {
        return expenseRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Expense not found"));
    }

    public Double getMonthlyCategorySpending(
            Long userId,
            Long categoryId,
            LocalDate startDate,
            LocalDate endDate) {

        Double total = expenseRepository
                .findTotalAmountByUserIdAndCategoryIdAndDateBetween(
                        userId,
                        categoryId,
                        startDate,
                        endDate
                );

        return total != null ? total : 0.0;
    }

    public Double getMonthlySpending(
            Long userId,
            Long categoryId,
            Integer month,
            Integer year) {

        LocalDate startDate = LocalDate.of(year, month, 1);
        LocalDate endDate = startDate.withDayOfMonth(startDate.lengthOfMonth());

        return getMonthlyCategorySpending(
                userId,
                categoryId,
                startDate,
                endDate
        );
    }

    private void checkBudgetAlert(Expense expense) {

        LocalDate expenseDate = expense.getDate();

        int month = expenseDate.getMonthValue();
        int year = expenseDate.getYear();

        Long userId = expense.getUser().getId();
        Long categoryId = expense.getCategory().getId();

        Budget budget = budgetService.getBudget(
                userId,
                categoryId,
                month,
                year
        );

        if (budget == null) {
            return;
        }

        LocalDate startDate = expenseDate.withDayOfMonth(1);

        LocalDate endDate = expenseDate
                .withDayOfMonth(expenseDate.lengthOfMonth());

        Double totalSpending = getMonthlyCategorySpending(
                userId,
                categoryId,
                startDate,
                endDate
        );

        double alertLimit = budget.getAmount() * 0.90;

        if (totalSpending >= alertLimit) {

            System.out.println(
                    "BUDGET ALERT: Spending has reached 90% of the budget."
            );
        }
    }

    public void deleteExpense(Long id) {
        if (!expenseRepository.existsById(id)) {
            throw new RuntimeException("Expense not found");
        }

        expenseRepository.deleteById(id);
    }
}