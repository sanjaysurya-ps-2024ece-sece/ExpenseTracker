package com.example.JarExpense.expense;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/expenses")
public class ExpenseController {

    private final ExpenseService expenseService;

    public ExpenseController(ExpenseService expenseService) {
        this.expenseService = expenseService;
    }

    @PostMapping
    public Expense createExpense(@RequestBody Expense expense) {
        return expenseService.createExpense(expense);
    }

    @GetMapping
    public List<Expense> getAllExpenses() {
        return expenseService.getAllExpenses();
    }

    @GetMapping("/{id}")
    public Expense getExpenseById(@PathVariable Long id) {
        return expenseService.getExpenseById(id);
    }

    @GetMapping("/monthly")
    public Double getMonthlySpending(
            @RequestParam Long userId,
            @RequestParam Long categoryId,
            @RequestParam String startDate,
            @RequestParam String endDate) {

        return expenseService.getMonthlyCategorySpending(
                userId,
                categoryId,
                java.time.LocalDate.parse(startDate),
                java.time.LocalDate.parse(endDate)
        );
    }

    @GetMapping({"/trend", "/monthly-trend"})
    public Double getMonthlySpendingTrend(
            @RequestParam Long userId,
            @RequestParam Long categoryId,
            @RequestParam Integer month,
            @RequestParam Integer year) {

        return expenseService.getMonthlySpending(
                userId,
                categoryId,
                month,
                year
        );
    }

    @DeleteMapping("/{id}")
    public void deleteExpense(@PathVariable Long id) {
        expenseService.deleteExpense(id);
    }
}