package com.example.JarExpense.category;

import com.example.JarExpense.budget.BudgetRepository;
import com.example.JarExpense.expense.ExpenseRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {

    private final CategoryRepository categoryRepository;
    private final BudgetRepository budgetRepository;
    private final ExpenseRepository expenseRepository;

    public CategoryService(
            CategoryRepository categoryRepository,
            BudgetRepository budgetRepository,
            ExpenseRepository expenseRepository
    ) {
        this.categoryRepository = categoryRepository;
        this.budgetRepository = budgetRepository;
        this.expenseRepository = expenseRepository;
    }

    public Category createCategory(Category category) {
        return categoryRepository.save(category);
    }

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    public Category getCategoryById(Long id) {
        return categoryRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Category not found"));
    }

    public void deleteCategory(Long id) {

        if (!categoryRepository.existsById(id)) {
            throw new RuntimeException("Category not found");
        }

        if (budgetRepository.existsByCategoryId(id)) {
            throw new RuntimeException(
                    "Cannot delete category because it is used by a budget"
            );
        }

        if (expenseRepository.existsByCategoryId(id)) {
            throw new RuntimeException(
                    "Cannot delete category because it is used by an expense"
            );
        }

        categoryRepository.deleteById(id);
    }
}