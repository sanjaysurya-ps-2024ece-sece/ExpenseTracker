package com.example.JarExpense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JarExpenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(JarExpenseApplication.class, args);
	}

}
