package com.example.JarExpense.budget;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BudgetService {

    private final BudgetRepository budgetRepository;

    public BudgetService(BudgetRepository budgetRepository) {
        this.budgetRepository = budgetRepository;
    }

    public Budget createBudget(Budget budget) {

        if (budget.getAmount() == null || budget.getAmount() <= 0) {
            throw new RuntimeException("Budget amount must be greater than 0");
        }

        return budgetRepository.save(budget);
    }

    public List<Budget> getAllBudgets() {
        return budgetRepository.findAll();
    }

    public Budget getBudgetById(Long id) {
        return budgetRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Budget not found"));
    }

    public Budget getBudget(
            Long userId,
            Long categoryId,
            Integer month,
            Integer year) {

        return budgetRepository
                .findByUserIdAndCategoryIdAndMonthAndYear(
                        userId,
                        categoryId,
                        month,
                        year
                )
                .orElse(null);
    }
}