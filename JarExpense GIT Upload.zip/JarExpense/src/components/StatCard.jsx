import React from 'react';

const StatCard = ({ title, value, icon, color = 'blue', subtitle, statusBadge }) => {
  return (
    <div className="stat-card">
      <div className="stat-header">
        <span className="stat-label">{title}</span>
        {icon && <div className={`stat-icon ${color}`}>{icon}</div>}
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-footer">
        {statusBadge && <span className={`badge badge-${statusBadge.type}`}>{statusBadge.text}</span>}
        {subtitle && <span>{subtitle}</span>}
      </div>
    </div>
  );
};

export default StatCard;
