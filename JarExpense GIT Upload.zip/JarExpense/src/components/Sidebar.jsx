import React from 'react';
import { NavLink } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const Sidebar = ({ isOpen, onClose }) => {
  const { budgetAlerts } = useApp();

  const navItems = [
    { to: '/', label: 'Dashboard', icon: '⚡' },
    { to: '/expenses', label: 'Expenses', icon: '💳' },
    { to: '/categories', label: 'Categories', icon: '🏷️' },
    {
      to: '/budgets',
      label: 'Budgets',
      icon: '🎯',
      badge: budgetAlerts.length > 0 ? budgetAlerts.length : null,
    },
    { to: '/reports', label: 'Reports', icon: '📈' },
  ];

  return (
    <>
      {isOpen && <div className="sidebar-backdrop" onClick={onClose} aria-hidden="true" />}
      <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <NavLink to="/" className="logo" onClick={onClose}>
            <div className="logo-icon">EJ</div>
            <span>ExpenseJar</span>
          </NavLink>
        </div>

        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
              onClick={onClose}
              end={item.to === '/'}
            >
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
              {item.badge && <span className="nav-badge">{item.badge}</span>}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          <NavLink
            to="/settings"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            onClick={onClose}
          >
            <span className="nav-icon">⚙️</span>
            <span>Settings</span>
          </NavLink>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
