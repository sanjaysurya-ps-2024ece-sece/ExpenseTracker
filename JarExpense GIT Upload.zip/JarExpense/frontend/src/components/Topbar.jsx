import { Bell, UserCircle } from "lucide-react";

function Topbar() {
    return (
        <header className="topbar">
            <div>
                <h1>Dashboard</h1>
                <p>Track and manage your personal expenses</p>
            </div>

            <div className="topbar-actions">
                <button className="icon-button">
                    <Bell size={20} />
                </button>

                <div className="user-profile">
                    <UserCircle size={34} />
                    <div>
                        <strong>Sanjay</strong>
                        <span>Personal Account</span>
                    </div>
                </div>
            </div>
        </header>
    );
}

export default Topbar;