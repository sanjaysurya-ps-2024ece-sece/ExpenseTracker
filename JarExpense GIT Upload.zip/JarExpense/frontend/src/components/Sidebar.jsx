import { NavLink } from "react-router-dom";
import {
    LayoutDashboard,
    Receipt,
    Tags,
    Wallet,
    BarChart3,
    Settings,
} from "lucide-react";

function Sidebar() {
    return (
        <aside className="sidebar">
            <div className="sidebar-logo">
                <h2>ExpenseJar</h2>
            </div>

            <nav className="sidebar-nav">
                <NavLink to="/" end>
                    <LayoutDashboard size={20} />
                    <span>Dashboard</span>
                </NavLink>

                <NavLink to="/expenses">
                    <Receipt size={20} />
                    <span>Expenses</span>
                </NavLink>

                <NavLink to="/categories">
                    <Tags size={20} />
                    <span>Categories</span>
                </NavLink>

                <NavLink to="/budgets">
                    <Wallet size={20} />
                    <span>Budgets</span>
                </NavLink>

                <NavLink to="/reports">
                    <BarChart3 size={20} />
                    <span>Reports</span>
                </NavLink>

                <NavLink to="/settings">
                    <Settings size={20} />
                    <span>Settings</span>
                </NavLink>
            </nav>
        </aside>
    );
}

export default Sidebar;