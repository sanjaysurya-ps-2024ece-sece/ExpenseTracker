import api from "./api.js";

export const getCategories = () => {
    return api.get("/categories");
};

export const getCategoryById = (id) => {
    return api.get(`/categories/${id}`);
};

export const createCategory = (category) => {
    return api.post("/categories", category);
};

export const deleteCategory = (id) => {
    return api.delete(`/categories/${id}`);
};