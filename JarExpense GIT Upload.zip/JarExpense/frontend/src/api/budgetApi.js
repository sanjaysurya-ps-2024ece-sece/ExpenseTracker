import api from "./api.js";

export const getBudgets = async () => {
    return await api.get("/budgets");
};

export const getBudgetById = async (id) => {
    return await api.get(`/budgets/${id}`);
};

export const createBudget = async (budget) => {
    return await api.post("/budgets", budget);
};