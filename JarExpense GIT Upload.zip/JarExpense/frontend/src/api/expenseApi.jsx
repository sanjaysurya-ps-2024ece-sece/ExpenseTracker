import api from "./api.js";

export const getExpenses = async () => {
    return await api.get("/expenses");
};

export const getExpenseById = async (id) => {
    return await api.get(`/expenses/${id}`);
};

export const createExpense = async (expense) => {
    return await api.post("/expenses", expense);
};

export const deleteExpense = async (id) => {
    return await api.delete(`/expenses/${id}`);
};

export const getMonthlySpending = async (
    userId,
    categoryId,
    startDate,
    endDate
) => {
    return await api.get("/expenses/monthly", {
        params: {
            userId,
            categoryId,
            startDate,
            endDate,
        },
    });
};