import { useEffect, useState } from "react";
import {
    getBudgets,
    createBudget,
} from "../api/budgetApi.js";
import { getCategories } from "../api/categoryApi.js";

function Budgets() {
    const [budgets, setBudgets] = useState([]);
    const [categories, setCategories] = useState([]);

    const [amount, setAmount] = useState("");
    const [month, setMonth] = useState("");
    const [year, setYear] = useState("");
    const [categoryId, setCategoryId] = useState("");

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const userId = 1;

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [budgetResponse, categoryResponse] =
                await Promise.all([
                    getBudgets(),
                    getCategories(),
                ]);

            setBudgets(budgetResponse.data || []);
            setCategories(categoryResponse.data || []);

        } catch (err) {
            console.error(err);
            setError("Unable to load budget data.");
        } finally {
            setLoading(false);
        }
    };

    const handleAddBudget = async (e) => {
        e.preventDefault();

        if (!amount || !month || !year || !categoryId) {
            setError("Please fill in all fields.");
            return;
        }

        if (Number(amount) <= 0) {
            setError("Budget amount must be greater than 0.");
            return;
        }

        if (Number(month) < 1 || Number(month) > 12) {
            setError("Please select a valid month.");
            return;
        }

        if (Number(year) < 2020) {
            setError("Please enter a valid year.");
            return;
        }

        try {
            const newBudget = {
                amount: Number(amount),
                month: Number(month),
                year: Number(year),
                user: {
                    id: userId,
                },
                category: {
                    id: Number(categoryId),
                },
            };

            await createBudget(newBudget);

            setAmount("");
            setMonth("");
            setYear("");
            setCategoryId("");
            setError("");

            await loadData();

        } catch (err) {
            console.error(err);

            let message = "Failed to add budget.";

            if (err.response?.data?.message) {
                message = err.response.data.message;
            } else if (
                typeof err.response?.data === "string"
            ) {
                message = err.response.data;
            } else if (err.response?.status === 500) {
                message =
                    "Unable to add budget. Please check the entered data.";
            }

            setError(message);
        }
    };

    const getMonthName = (monthNumber) => {
        const months = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
        ];

        return (
            months[Number(monthNumber) - 1] ||
            "Unknown"
        );
    };

    return (
        <div>

            {/* PAGE HEADER */}

            <div className="page-header">
                <div>
                    <h1>Budgets</h1>

                    <p>
                        Plan and manage your spending limits
                    </p>
                </div>
            </div>

            {/* ERROR MESSAGE */}

            {error && (
                <div className="alert">
                    {error}
                </div>
            )}

            {/* ADD BUDGET */}

            <div className="dashboard-card">

                <div className="dashboard-card-header">

                    <div>
                        <h3>Add Budget</h3>

                        <p>
                            Create a monthly category budget
                        </p>
                    </div>

                </div>

                <form onSubmit={handleAddBudget}>

                    <div
                        style={{
                            display: "grid",
                            gridTemplateColumns:
                                "repeat(4, 1fr)",
                            gap: "16px",
                        }}
                    >

                        {/* AMOUNT */}

                        <div className="form-group">

                            <label>
                                Amount
                            </label>

                            <input
                                type="number"
                                placeholder="Enter budget"
                                value={amount}
                                onChange={(e) =>
                                    setAmount(
                                        e.target.value
                                    )
                                }
                                min="0"
                                step="0.01"
                            />

                        </div>

                        {/* MONTH */}

                        <div className="form-group">

                            <label>
                                Month
                            </label>

                            <select
                                value={month}
                                onChange={(e) =>
                                    setMonth(
                                        e.target.value
                                    )
                                }
                            >

                                <option value="">
                                    Select month
                                </option>

                                <option value="1">
                                    January
                                </option>

                                <option value="2">
                                    February
                                </option>

                                <option value="3">
                                    March
                                </option>

                                <option value="4">
                                    April
                                </option>

                                <option value="5">
                                    May
                                </option>

                                <option value="6">
                                    June
                                </option>

                                <option value="7">
                                    July
                                </option>

                                <option value="8">
                                    August
                                </option>

                                <option value="9">
                                    September
                                </option>

                                <option value="10">
                                    October
                                </option>

                                <option value="11">
                                    November
                                </option>

                                <option value="12">
                                    December
                                </option>

                            </select>

                        </div>

                        {/* YEAR */}

                        <div className="form-group">

                            <label>
                                Year
                            </label>

                            <input
                                type="number"
                                placeholder="2026"
                                value={year}
                                onChange={(e) =>
                                    setYear(
                                        e.target.value
                                    )
                                }
                                min="2020"
                            />

                        </div>

                        {/* CATEGORY */}

                        <div className="form-group">

                            <label>
                                Category
                            </label>

                            <select
                                value={categoryId}
                                onChange={(e) =>
                                    setCategoryId(
                                        e.target.value
                                    )
                                }
                            >

                                <option value="">
                                    Select category
                                </option>

                                {categories.map(
                                    (category) => (
                                        <option
                                            key={
                                                category.id
                                            }
                                            value={
                                                category.id
                                            }
                                        >
                                            {
                                                category.name
                                            }
                                        </option>
                                    )
                                )}

                            </select>

                        </div>

                    </div>

                    <button
                        type="submit"
                        className="btn btn-primary"
                    >
                        Add Budget
                    </button>

                </form>

            </div>

            {/* BUDGET LIST */}

            <div
                className="dashboard-card"
                style={{
                    marginTop: "20px",
                }}
            >

                <div className="dashboard-card-header">

                    <div>

                        <h3>
                            Current Budgets
                        </h3>

                        <p>
                            Your configured spending limits
                        </p>

                    </div>

                </div>

                {/* LOADING */}

                {loading ? (

                    <div className="empty-state">

                        <h3>
                            Loading budgets...
                        </h3>

                        <p>
                            Getting your latest budgets.
                        </p>

                    </div>

                ) : budgets.length === 0 ? (

                    /* EMPTY STATE */

                    <div className="empty-state">

                        <h3>
                            No budgets found
                        </h3>

                        <p>
                            Add your first budget above.
                        </p>

                    </div>

                ) : (

                    /* BUDGET TABLE */

                    <div className="table-container">

                        <table>

                            <thead>

                            <tr>

                                <th>
                                    ID
                                </th>

                                <th>
                                    Category
                                </th>

                                <th>
                                    Month
                                </th>

                                <th>
                                    Year
                                </th>

                                <th>
                                    Budget
                                </th>

                            </tr>

                            </thead>

                            <tbody>

                            {budgets.map(
                                (budget) => (

                                    <tr
                                        key={
                                            budget.id
                                        }
                                    >

                                        <td>
                                            #
                                            {
                                                budget.id
                                            }
                                        </td>

                                        <td>
                                            {
                                                budget
                                                    .category
                                                    ?.name ||
                                                "Uncategorized"
                                            }
                                        </td>

                                        <td>
                                            {
                                                getMonthName(
                                                    budget.month
                                                )
                                            }
                                        </td>

                                        <td>
                                            {
                                                budget.year
                                            }
                                        </td>

                                        <td>

                                            <strong>
                                                ₹
                                                {Number(
                                                    budget.amount ||
                                                    0
                                                ).toFixed(
                                                    2
                                                )}
                                            </strong>

                                        </td>

                                    </tr>

                                )
                            )}

                            </tbody>

                        </table>

                    </div>

                )}

            </div>

        </div>
    );
}

export default Budgets;