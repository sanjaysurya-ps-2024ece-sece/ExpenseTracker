import { useEffect, useState } from "react";
import {
    getCategories,
    createCategory,
    deleteCategory,
} from "../api/categoryApi.js";

function Categories() {
    const [categories, setCategories] = useState([]);
    const [name, setName] = useState("");

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [categoryToDelete, setCategoryToDelete] = useState(null);

    useEffect(() => {
        loadCategories();
    }, []);

    const loadCategories = async () => {
        try {
            const response = await getCategories();

            setCategories(response.data);
        } catch (err) {
            console.error(err);

            setError("Unable to load categories.");
        } finally {
            setLoading(false);
        }
    };

    const handleAddCategory = async (e) => {
        e.preventDefault();

        const trimmedName = name.trim();

        if (!trimmedName) {
            setError("Please enter a category name.");
            return;
        }

        // Prevent duplicate category names
        const alreadyExists = categories.some(
            (category) =>
                category.name?.trim().toLowerCase() ===
                trimmedName.toLowerCase()
        );

        if (alreadyExists) {
            setError(`"${trimmedName}" already exists.`);
            return;
        }

        try {
            await createCategory({
                name: trimmedName,
            });

            setName("");
            setError("");

            await loadCategories();
        } catch (err) {
            console.error(err);

            let message = "Failed to add category.";

            if (err.response?.data?.message) {
                message = err.response.data.message;
            } else if (typeof err.response?.data === "string") {
                message = err.response.data;
            }

            setError(message);
        }
    };

    const openDeleteModal = (category) => {
        setCategoryToDelete(category);
        setShowDeleteModal(true);
    };

    const closeDeleteModal = () => {
        setShowDeleteModal(false);
        setCategoryToDelete(null);
    };

    const confirmDelete = async () => {
        if (!categoryToDelete) {
            return;
        }

        try {
            await deleteCategory(categoryToDelete.id);

            closeDeleteModal();
            setError("");

            await loadCategories();
        } catch (err) {
            console.error(err);

            let message =
                "Unable to delete this category.";

            // If backend sends { message: "..." }
            if (err.response?.data?.message) {
                message = err.response.data.message;
            }

            // If backend sends plain text
            else if (
                typeof err.response?.data === "string"
            ) {
                message = err.response.data;
            }

            // Fallback for Spring Boot HTTP 500
            else if (err.response?.status === 500) {
                message =
                    "Cannot delete this category because it is used by a budget or expense.";
            }

            setError(message);

            closeDeleteModal();
        }
    };

    return (
        <div>
            {/* PAGE HEADER */}
            <div className="page-header">
                <div>
                    <h1>Categories</h1>
                    <p>Manage your expense categories</p>
                </div>
            </div>

            {/* ERROR MESSAGE */}
            {error && (
                <div className="alert">
                    {error}
                </div>
            )}

            {/* ADD CATEGORY CARD */}
            <div className="dashboard-card">
                <div className="dashboard-card-header">
                    <div>
                        <h3>Add Category</h3>
                        <p>
                            Create a new expense category
                        </p>
                    </div>
                </div>

                <form onSubmit={handleAddCategory}>
                    <div className="form-group">
                        <label>Category Name</label>

                        <input
                            type="text"
                            placeholder="e.g. Transport"
                            value={name}
                            onChange={(e) =>
                                setName(e.target.value)
                            }
                        />
                    </div>

                    <button
                        type="submit"
                        className="btn btn-primary"
                    >
                        Add Category
                    </button>
                </form>
            </div>

            {/* CATEGORY LIST CARD */}
            <div
                className="dashboard-card"
                style={{ marginTop: "20px" }}
            >
                <div className="dashboard-card-header">
                    <div>
                        <h3>Categories</h3>
                        <p>
                            Your available expense categories
                        </p>
                    </div>
                </div>

                {/* LOADING */}
                {loading ? (
                    <div className="empty-state">
                        <h3>Loading categories...</h3>
                    </div>
                ) : categories.length === 0 ? (
                    /* EMPTY */
                    <div className="empty-state">
                        <h3>No categories found</h3>
                        <p>
                            Add your first category above.
                        </p>
                    </div>
                ) : (
                    /* TABLE */
                    <div className="table-container">
                        <table>
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category Name</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            {categories.map(
                                (category) => (
                                    <tr
                                        key={
                                            category.id
                                        }
                                    >
                                        <td>
                                            #
                                            {
                                                category.id
                                            }
                                        </td>

                                        <td>
                                            {
                                                category.name
                                            }
                                        </td>

                                        <td>
                                            <button
                                                className="btn btn-danger"
                                                onClick={() =>
                                                    openDeleteModal(
                                                        category
                                                    )
                                                }
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                )
                            )}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* DELETE CONFIRMATION MODAL */}
            {showDeleteModal &&
                categoryToDelete && (
                    <div
                        style={{
                            position: "fixed",
                            inset: 0,
                            background:
                                "rgba(0, 0, 0, 0.45)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            zIndex: 1000,
                            padding: "20px",
                        }}
                    >
                        <div
                            style={{
                                width: "100%",
                                maxWidth: "420px",
                                background: "#ffffff",
                                borderRadius: "16px",
                                padding: "28px",
                                boxShadow:
                                    "0 20px 60px rgba(0, 0, 0, 0.2)",
                            }}
                        >
                            {/* WARNING ICON */}
                            <div
                                style={{
                                    width: "48px",
                                    height: "48px",
                                    borderRadius: "50%",
                                    background: "#f3f3f3",
                                    display: "flex",
                                    alignItems:
                                        "center",
                                    justifyContent:
                                        "center",
                                    marginBottom:
                                        "18px",
                                    fontSize: "22px",
                                    fontWeight: "700",
                                }}
                            >
                                !
                            </div>

                            {/* TITLE */}
                            <h2
                                style={{
                                    margin:
                                        "0 0 8px",
                                    fontSize: "22px",
                                }}
                            >
                                Delete category?
                            </h2>

                            {/* DESCRIPTION */}
                            <p
                                style={{
                                    margin:
                                        "0 0 8px",
                                    color: "#666",
                                    lineHeight: "1.6",
                                }}
                            >
                                Are you sure you want
                                to delete this
                                category?
                            </p>

                            {/* CATEGORY */}
                            <p
                                style={{
                                    margin:
                                        "0 0 24px",
                                    fontWeight: "600",
                                }}
                            >
                                {
                                    categoryToDelete.name
                                }
                            </p>

                            {/* ACTION BUTTONS */}
                            <div
                                style={{
                                    display: "flex",
                                    justifyContent:
                                        "flex-end",
                                    gap: "10px",
                                }}
                            >
                                <button
                                    className="btn"
                                    onClick={
                                        closeDeleteModal
                                    }
                                >
                                    Cancel
                                </button>

                                <button
                                    className="btn btn-danger"
                                    onClick={
                                        confirmDelete
                                    }
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                )}
        </div>
    );
}

export default Categories;