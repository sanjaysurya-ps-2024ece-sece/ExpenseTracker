import { useEffect, useState } from "react";
import {
    getExpenses,
    createExpense,
    deleteExpense,
} from "../api/expenseApi.jsx";
import { getCategories } from "../api/categoryApi.js";

function Expenses() {
    const [expenses, setExpenses] = useState([]);
    const [categories, setCategories] = useState([]);

    const [amount, setAmount] = useState("");
    const [date, setDate] = useState("");
    const [categoryId, setCategoryId] = useState("");

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [expenseToDelete, setExpenseToDelete] = useState(null);

    const userId = 1;

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [expenseResponse, categoryResponse] =
                await Promise.all([
                    getExpenses(),
                    getCategories(),
                ]);

            setExpenses(expenseResponse.data);
            setCategories(categoryResponse.data);
        } catch (err) {
            console.error(err);

            setError("Unable to load expenses.");
        } finally {
            setLoading(false);
        }
    };

    const handleAddExpense = async (e) => {
        e.preventDefault();

        if (!amount || !date || !categoryId) {
            setError("Please fill in all fields.");
            return;
        }

        if (Number(amount) <= 0) {
            setError("Amount must be greater than 0.");
            return;
        }

        try {
            const newExpense = {
                amount: Number(amount),
                date: date,
                user: {
                    id: userId,
                },
                category: {
                    id: Number(categoryId),
                },
            };

            await createExpense(newExpense);

            setAmount("");
            setDate("");
            setCategoryId("");
            setError("");

            await loadData();
        } catch (err) {
            console.error(err);

            let message = "Failed to add expense.";

            if (err.response?.data?.message) {
                message = err.response.data.message;
            } else if (
                typeof err.response?.data === "string"
            ) {
                message = err.response.data;
            } else if (err.response?.status === 500) {
                message =
                    "Unable to add expense. Please check the entered data.";
            }

            setError(message);
        }
    };

    const openDeleteModal = (expense) => {
        setExpenseToDelete(expense);
        setShowDeleteModal(true);
    };

    const closeDeleteModal = () => {
        setShowDeleteModal(false);
        setExpenseToDelete(null);
    };

    const confirmDelete = async () => {
        if (!expenseToDelete) {
            return;
        }

        try {
            await deleteExpense(expenseToDelete.id);

            closeDeleteModal();
            setError("");

            await loadData();
        } catch (err) {
            console.error(err);

            let message =
                "Unable to delete this expense.";

            if (err.response?.data?.message) {
                message = err.response.data.message;
            } else if (
                typeof err.response?.data === "string"
            ) {
                message = err.response.data;
            } else if (err.response?.status === 500) {
                message =
                    "Unable to delete this expense because it is being used by another record.";
            }

            setError(message);

            closeDeleteModal();
        }
    };

    return (
        <div>
            {/* PAGE HEADER */}
            <div className="page-header">
                <div>
                    <h1>Expenses</h1>
                    <p>Manage your personal expenses</p>
                </div>
            </div>

            {/* ERROR MESSAGE */}
            {error && (
                <div className="alert">
                    {error}
                </div>
            )}

            {/* ADD EXPENSE */}
            <div className="dashboard-card">
                <div className="dashboard-card-header">
                    <div>
                        <h3>Add Expense</h3>
                        <p>Record a new expense</p>
                    </div>
                </div>

                <form onSubmit={handleAddExpense}>
                    <div
                        style={{
                            display: "grid",
                            gridTemplateColumns:
                                "repeat(3, 1fr)",
                            gap: "16px",
                        }}
                    >
                        {/* AMOUNT */}
                        <div className="form-group">
                            <label>Amount</label>

                            <input
                                type="number"
                                placeholder="Enter amount"
                                value={amount}
                                onChange={(e) =>
                                    setAmount(
                                        e.target.value
                                    )
                                }
                                min="0"
                                step="0.01"
                            />
                        </div>

                        {/* DATE */}
                        <div className="form-group">
                            <label>Date</label>

                            <input
                                type="date"
                                value={date}
                                onChange={(e) =>
                                    setDate(
                                        e.target.value
                                    )
                                }
                            />
                        </div>

                        {/* CATEGORY */}
                        <div className="form-group">
                            <label>Category</label>

                            <select
                                value={categoryId}
                                onChange={(e) =>
                                    setCategoryId(
                                        e.target.value
                                    )
                                }
                            >
                                <option value="">
                                    Select category
                                </option>

                                {categories.map(
                                    (category) => (
                                        <option
                                            key={
                                                category.id
                                            }
                                            value={
                                                category.id
                                            }
                                        >
                                            {
                                                category.name
                                            }
                                        </option>
                                    )
                                )}
                            </select>
                        </div>
                    </div>

                    <button
                        type="submit"
                        className="btn btn-primary"
                    >
                        Add Expense
                    </button>
                </form>
            </div>

            {/* EXPENSE LIST */}
            <div
                className="dashboard-card"
                style={{ marginTop: "20px" }}
            >
                <div className="dashboard-card-header">
                    <div>
                        <h3>All Expenses</h3>
                        <p>
                            Your recorded transactions
                        </p>
                    </div>
                </div>

                {loading ? (
                    <div className="empty-state">
                        <h3>Loading expenses...</h3>
                    </div>
                ) : expenses.length === 0 ? (
                    <div className="empty-state">
                        <h3>No expenses found</h3>
                        <p>
                            Add your first expense above.
                        </p>
                    </div>
                ) : (
                    <div className="table-container">
                        <table>
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category</th>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            {expenses.map(
                                (expense) => (
                                    <tr
                                        key={
                                            expense.id
                                        }
                                    >
                                        <td>
                                            #
                                            {
                                                expense.id
                                            }
                                        </td>

                                        <td>
                                            {expense
                                                    .category
                                                    ?.name ||
                                                "Uncategorized"}
                                        </td>

                                        <td>
                                            {
                                                expense.date
                                            }
                                        </td>

                                        <td>
                                            ₹
                                            {Number(
                                                expense.amount ||
                                                0
                                            ).toFixed(2)}
                                        </td>

                                        <td>
                                            <button
                                                className="btn btn-danger"
                                                onClick={() =>
                                                    openDeleteModal(
                                                        expense
                                                    )
                                                }
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                )
                            )}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* DELETE CONFIRMATION MODAL */}
            {showDeleteModal &&
                expenseToDelete && (
                    <div
                        style={{
                            position: "fixed",
                            inset: 0,
                            background:
                                "rgba(0, 0, 0, 0.45)",
                            display: "flex",
                            alignItems:
                                "center",
                            justifyContent:
                                "center",
                            zIndex: 1000,
                            padding: "20px",
                        }}
                    >
                        <div
                            style={{
                                width: "100%",
                                maxWidth: "420px",
                                background:
                                    "#ffffff",
                                borderRadius:
                                    "16px",
                                padding:
                                    "28px",
                                boxShadow:
                                    "0 20px 60px rgba(0, 0, 0, 0.2)",
                            }}
                        >
                            {/* ICON */}
                            <div
                                style={{
                                    width: "48px",
                                    height:
                                        "48px",
                                    borderRadius:
                                        "50%",
                                    background:
                                        "#f3f3f3",
                                    display:
                                        "flex",
                                    alignItems:
                                        "center",
                                    justifyContent:
                                        "center",
                                    marginBottom:
                                        "18px",
                                    fontSize:
                                        "22px",
                                    fontWeight:
                                        "700",
                                }}
                            >
                                !
                            </div>

                            {/* TITLE */}
                            <h2
                                style={{
                                    margin:
                                        "0 0 8px",
                                    fontSize:
                                        "22px",
                                }}
                            >
                                Delete expense?
                            </h2>

                            {/* DESCRIPTION */}
                            <p
                                style={{
                                    margin:
                                        "0 0 8px",
                                    color:
                                        "#666",
                                    lineHeight:
                                        "1.6",
                                }}
                            >
                                Are you sure you
                                want to delete
                                this expense?
                            </p>

                            {/* EXPENSE DETAILS */}
                            <p
                                style={{
                                    margin:
                                        "0 0 24px",
                                    fontWeight:
                                        "600",
                                }}
                            >
                                {expenseToDelete
                                        .category
                                        ?.name ||
                                    "Uncategorized"}{" "}
                                · ₹
                                {Number(
                                    expenseToDelete.amount ||
                                    0
                                ).toFixed(2)}
                            </p>

                            {/* BUTTONS */}
                            <div
                                style={{
                                    display:
                                        "flex",
                                    justifyContent:
                                        "flex-end",
                                    gap: "10px",
                                }}
                            >
                                <button
                                    className="btn"
                                    onClick={
                                        closeDeleteModal
                                    }
                                >
                                    Cancel
                                </button>

                                <button
                                    className="btn btn-danger"
                                    onClick={
                                        confirmDelete
                                    }
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                )}
        </div>
    );
}

export default Expenses;