function Settings() {
    return (
        <div>

            <div className="page-header">
                <div>
                    <h1>Settings</h1>
                    <p>Manage your ExpenseJar preferences</p>
                </div>
            </div>

            <div className="dashboard-card">

                <div className="dashboard-card-header">
                    <div>
                        <h3>Account</h3>
                        <p>Your personal account information</p>
                    </div>
                </div>

                <div className="form-group">
                    <label>Name</label>
                    <input
                        type="text"
                        value="Sanjay"
                        readOnly
                    />
                </div>

                <div className="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        value="sanjay@example.com"
                        readOnly
                    />
                </div>

            </div>

            <div
                className="dashboard-card"
                style={{ marginTop: "20px" }}
            >

                <div className="dashboard-card-header">
                    <div>
                        <h3>Application</h3>
                        <p>ExpenseJar application information</p>
                    </div>
                </div>

                <div
                    style={{
                        display: "flex",
                        justifyContent: "space-between",
                        padding: "14px 0",
                        borderBottom:
                            "1px solid #e5e5e5",
                    }}
                >
                    <span>Application</span>
                    <strong>ExpenseJar</strong>
                </div>

                <div
                    style={{
                        display: "flex",
                        justifyContent: "space-between",
                        padding: "14px 0",
                    }}
                >
                    <span>Version</span>
                    <strong>1.0.0</strong>
                </div>

            </div>

        </div>
    );
}

export default Settings;