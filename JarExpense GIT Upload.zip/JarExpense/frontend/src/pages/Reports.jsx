import { useEffect, useMemo, useState } from "react";
import { getExpenses } from "../api/expenseApi.jsx";

import {
    BarChart,
    Bar,
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
} from "recharts";

function Reports() {
    const [expenses, setExpenses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        loadExpenses();
    }, []);

    const loadExpenses = async () => {
        try {
            const response = await getExpenses();

            setExpenses(response.data || []);
        } catch (err) {
            console.error(err);

            setError(
                "Unable to load report data."
            );
        } finally {
            setLoading(false);
        }
    };

    // --------------------------------------------------
    // TOTAL SPENDING
    // --------------------------------------------------

    const totalSpending = useMemo(() => {
        return expenses.reduce(
            (total, expense) =>
                total +
                Number(expense.amount || 0),
            0
        );
    }, [expenses]);

    // --------------------------------------------------
    // AVERAGE EXPENSE
    // --------------------------------------------------

    const averageExpense = useMemo(() => {
        if (expenses.length === 0) {
            return 0;
        }

        return (
            totalSpending /
            expenses.length
        );
    }, [expenses, totalSpending]);

    // --------------------------------------------------
    // HIGHEST EXPENSE
    // --------------------------------------------------

    const highestExpense = useMemo(() => {
        if (expenses.length === 0) {
            return 0;
        }

        return Math.max(
            ...expenses.map((expense) =>
                Number(expense.amount || 0)
            )
        );
    }, [expenses]);

    // --------------------------------------------------
    // SPENDING BY CATEGORY
    // --------------------------------------------------

    const categoryData = useMemo(() => {
        const categories = {};

        expenses.forEach((expense) => {
            const category =
                expense.category?.name ||
                "Uncategorized";

            categories[category] =
                (categories[category] || 0) +
                Number(expense.amount || 0);
        });

        return Object.entries(categories)
            .map(
                ([category, amount]) => ({
                    category,
                    amount,
                })
            )
            .sort(
                (a, b) =>
                    b.amount - a.amount
            );
    }, [expenses]);

    // --------------------------------------------------
    // MONTHLY SPENDING
    // --------------------------------------------------

    const monthlyData = useMemo(() => {
        const months = {};

        expenses.forEach((expense) => {
            if (!expense.date) {
                return;
            }

            const date = new Date(
                expense.date
            );

            if (isNaN(date.getTime())) {
                return;
            }

            const monthKey =
                `${date.getFullYear()}-${String(
                    date.getMonth() + 1
                ).padStart(2, "0")}`;

            const monthName =
                date.toLocaleString(
                    "en-US",
                    {
                        month: "short",
                        year: "numeric",
                    }
                );

            if (!months[monthKey]) {
                months[monthKey] = {
                    month: monthName,
                    amount: 0,
                    sortKey: monthKey,
                };
            }

            months[monthKey].amount +=
                Number(expense.amount || 0);
        });

        return Object.values(months)
            .sort((a, b) =>
                a.sortKey.localeCompare(
                    b.sortKey
                )
            )
            .map(
                ({
                     month,
                     amount,
                 }) => ({
                    month,
                    amount,
                })
            );
    }, [expenses]);

    return (
        <div className="reports-page">

            {/* PAGE HEADER */}

            <div className="page-header">

                <div>

                    <h1>
                        Reports
                    </h1>

                    <p>
                        Analyze your spending
                        patterns
                    </p>

                </div>

            </div>

            {/* ERROR */}

            {error && (
                <div className="alert">
                    {error}
                </div>
            )}

            {/* SUMMARY CARDS */}

            <div className="stats-grid">

                {/* TOTAL SPENDING */}

                <div className="stat-card">

                    <div className="stat-label">
                        Total Spending
                    </div>

                    <div className="stat-value">
                        {loading
                            ? "Loading..."
                            : `₹${totalSpending.toFixed(
                                2
                            )}`}
                    </div>

                    <div className="stat-change">
                        All recorded expenses
                    </div>

                </div>

                {/* TRANSACTIONS */}

                <div className="stat-card">

                    <div className="stat-label">
                        Transactions
                    </div>

                    <div className="stat-value">
                        {loading
                            ? "..."
                            : expenses.length}
                    </div>

                    <div className="stat-change">
                        Total expenses
                    </div>

                </div>

                {/* AVERAGE */}

                <div className="stat-card">

                    <div className="stat-label">
                        Average Expense
                    </div>

                    <div className="stat-value">
                        {loading
                            ? "Loading..."
                            : `₹${averageExpense.toFixed(
                                2
                            )}`}
                    </div>

                    <div className="stat-change">
                        Per transaction
                    </div>

                </div>

                {/* HIGHEST */}

                <div className="stat-card">

                    <div className="stat-label">
                        Highest Expense
                    </div>

                    <div className="stat-value">
                        {loading
                            ? "Loading..."
                            : `₹${highestExpense.toFixed(
                                2
                            )}`}
                    </div>

                    <div className="stat-change">
                        Largest transaction
                    </div>

                </div>

            </div>

            {/* CATEGORY REPORT */}

            <div className="dashboard-card">

                <div className="dashboard-card-header">

                    <div>

                        <h3>
                            Spending by Category
                        </h3>

                        <p>
                            Compare your spending
                            across categories
                        </p>

                    </div>

                </div>

                {loading ? (

                    <div className="empty-state">

                        <h3>
                            Loading report...
                        </h3>

                        <p>
                            Calculating your
                            spending data.
                        </p>

                    </div>

                ) : categoryData.length === 0 ? (

                    <div className="empty-state">

                        <h3>
                            No spending data
                        </h3>

                        <p>
                            Add expenses to generate
                            category reports.
                        </p>

                    </div>

                ) : (

                    <div
                        style={{
                            width: "100%",
                            height: 320,
                        }}
                    >

                        <ResponsiveContainer
                            width="100%"
                            height="100%"
                        >

                            <BarChart
                                data={categoryData}
                            >

                                <CartesianGrid
                                    strokeDasharray="3 3"
                                />

                                <XAxis
                                    dataKey="category"
                                />

                                <YAxis />

                                <Tooltip
                                    formatter={(
                                        value
                                    ) => [
                                        `₹${Number(
                                            value
                                        ).toFixed(
                                            2
                                        )}`,
                                        "Spending",
                                    ]}
                                />

                                <Bar
                                    dataKey="amount"
                                    fill="#111111"
                                    radius={[
                                        4,
                                        4,
                                        0,
                                        0,
                                    ]}
                                />

                            </BarChart>

                        </ResponsiveContainer>

                    </div>

                )}

            </div>

            {/* MONTHLY REPORT */}

            <div
                className="dashboard-card"
                style={{
                    marginTop: "20px",
                }}
            >

                <div className="dashboard-card-header">

                    <div>

                        <h3>
                            Monthly Spending
                        </h3>

                        <p>
                            Track your spending
                            over time
                        </p>

                    </div>

                </div>

                {loading ? (

                    <div className="empty-state">

                        <h3>
                            Loading report...
                        </h3>

                        <p>
                            Calculating monthly
                            spending.
                        </p>

                    </div>

                ) : monthlyData.length === 0 ? (

                    <div className="empty-state">

                        <h3>
                            No monthly data
                        </h3>

                        <p>
                            Add expenses to generate
                            monthly analytics.
                        </p>

                    </div>

                ) : (

                    <div
                        style={{
                            width: "100%",
                            height: 320,
                        }}
                    >

                        <ResponsiveContainer
                            width="100%"
                            height="100%"
                        >

                            <LineChart
                                data={monthlyData}
                            >

                                <CartesianGrid
                                    strokeDasharray="3 3"
                                />

                                <XAxis
                                    dataKey="month"
                                />

                                <YAxis />

                                <Tooltip
                                    formatter={(
                                        value
                                    ) => [
                                        `₹${Number(
                                            value
                                        ).toFixed(
                                            2
                                        )}`,
                                        "Spending",
                                    ]}
                                />

                                <Line
                                    type="monotone"
                                    dataKey="amount"
                                    stroke="#111111"
                                    strokeWidth={3}
                                    dot={{
                                        r: 4,
                                    }}
                                />

                            </LineChart>

                        </ResponsiveContainer>

                    </div>

                )}

            </div>

            {/* EXPENSE BREAKDOWN */}

            <div
                className="dashboard-card"
                style={{
                    marginTop: "20px",
                }}
            >

                <div className="dashboard-card-header">

                    <div>

                        <h3>
                            Expense Breakdown
                        </h3>

                        <p>
                            Detailed transaction
                            summary
                        </p>

                    </div>

                </div>

                {loading ? (

                    <div className="empty-state">

                        <h3>
                            Loading expenses...
                        </h3>

                        <p>
                            Getting your
                            transactions.
                        </p>

                    </div>

                ) : expenses.length === 0 ? (

                    <div className="empty-state">

                        <h3>
                            No expenses
                        </h3>

                        <p>
                            Add expenses to see
                            the detailed
                            breakdown.
                        </p>

                    </div>

                ) : (

                    <div className="table-container">

                        <table>

                            <thead>

                            <tr>

                                <th>
                                    ID
                                </th>

                                <th>
                                    Category
                                </th>

                                <th>
                                    Date
                                </th>

                                <th>
                                    Amount
                                </th>

                            </tr>

                            </thead>

                            <tbody>

                            {expenses.map(
                                (expense) => (

                                    <tr
                                        key={
                                            expense.id
                                        }
                                    >

                                        <td>
                                            #
                                            {
                                                expense.id
                                            }
                                        </td>

                                        <td>
                                            {
                                                expense
                                                    .category
                                                    ?.name ||
                                                "Uncategorized"
                                            }
                                        </td>

                                        <td>
                                            {
                                                expense.date
                                            }
                                        </td>

                                        <td>

                                            <strong>
                                                ₹
                                                {Number(
                                                    expense.amount ||
                                                    0
                                                ).toFixed(
                                                    2
                                                )}
                                            </strong>

                                        </td>

                                    </tr>

                                )
                            )}

                            </tbody>

                        </table>

                    </div>

                )}

            </div>

        </div>
    );
}

export default Reports;