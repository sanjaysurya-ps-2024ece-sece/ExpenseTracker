import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
    Wallet,
    Receipt,
    TrendingUp,
    Plus,
    ArrowRight,
} from "lucide-react";

import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    LineChart,
    Line,
} from "recharts";

import { getExpenses } from "../api/expenseApi.jsx";
import { getBudgets } from "../api/budgetApi.js";

function Dashboard() {
    const [expenses, setExpenses] = useState([]);
    const [budgets, setBudgets] = useState([]);
    const [loading, setLoading] = useState(true);

    const userId = 1;

    useEffect(() => {
        loadDashboard();
    }, []);

    const loadDashboard = async () => {
        try {
            const [expenseResponse, budgetResponse] =
                await Promise.all([
                    getExpenses(),
                    getBudgets(),
                ]);

            setExpenses(expenseResponse.data || []);
            setBudgets(budgetResponse.data || []);
        } catch (err) {
            console.error("Dashboard loading error:", err);
        } finally {
            setLoading(false);
        }
    };

    const totalSpending = useMemo(() => {
        return expenses.reduce(
            (total, expense) =>
                total + Number(expense.amount || 0),
            0
        );
    }, [expenses]);

    const totalBudget = useMemo(() => {
        return budgets
            .filter(
                (budget) =>
                    budget.user?.id === userId
            )
            .reduce(
                (total, budget) =>
                    total + Number(budget.amount || 0),
                0
            );
    }, [budgets]);

    const remaining = totalBudget - totalSpending;

    const categoryData = useMemo(() => {
        const categoryMap = {};

        expenses.forEach((expense) => {
            const category =
                expense.category?.name ||
                "Uncategorized";

            categoryMap[category] =
                (categoryMap[category] || 0) +
                Number(expense.amount || 0);
        });

        return Object.entries(categoryMap).map(
            ([name, amount]) => ({
                name,
                amount,
            })
        );
    }, [expenses]);

    const monthlyData = useMemo(() => {
        const monthMap = {};

        expenses.forEach((expense) => {
            if (!expense.date) {
                return;
            }

            const date = new Date(expense.date);

            const monthName = date.toLocaleString(
                "en-US",
                {
                    month: "short",
                }
            );

            monthMap[monthName] =
                (monthMap[monthName] || 0) +
                Number(expense.amount || 0);
        });

        return Object.entries(monthMap).map(
            ([month, amount]) => ({
                month,
                amount,
            })
        );
    }, [expenses]);

    const recentExpenses = useMemo(() => {
        return [...expenses]
            .sort(
                (a, b) =>
                    new Date(b.date) -
                    new Date(a.date)
            )
            .slice(0, 5);
    }, [expenses]);

    if (loading) {
        return (
            <div className="empty-state">
                <h3>Loading dashboard...</h3>
                <p>
                    Getting your latest financial data.
                </p>
            </div>
        );
    }

    return (
        <div className="dashboard-page">

            {/* Dashboard actions */}
            <div className="page-header dashboard-page-header">
                <div></div>

                <Link
                    to="/expenses"
                    className="btn btn-primary dashboard-add-button"
                >
                    <Plus size={18} />
                    Add Expense
                </Link>
            </div>

            {/* Welcome section */}
            <div className="dashboard-welcome">
                <div className="dashboard-welcome-icon">
                    <Wallet size={24} />
                </div>

                <div>
                    <h2>Welcome to ExpenseJar</h2>

                    <p>
                        Keep track of your spending,
                        budgets and financial activity.
                    </p>
                </div>
            </div>

            {/* Statistics */}
            <div className="stats-grid dashboard-stats">

                {/* Total Spending */}
                <div className="stat-card">
                    <div className="stat-card-icon">
                        <TrendingUp size={20} />
                    </div>

                    <div className="stat-card-content">
                        <span>Total Spending</span>

                        <strong>
                            ₹{totalSpending.toFixed(2)}
                        </strong>

                        <small>
                            All expenses
                        </small>
                    </div>
                </div>

                {/* Total Budget */}
                <div className="stat-card">
                    <div className="stat-card-icon">
                        <Wallet size={20} />
                    </div>

                    <div className="stat-card-content">
                        <span>Total Budget</span>

                        <strong>
                            ₹{totalBudget.toFixed(2)}
                        </strong>

                        <small>
                            Current budgets
                        </small>
                    </div>
                </div>

                {/* Remaining */}
                <div className="stat-card">
                    <div className="stat-card-icon">
                        <TrendingUp size={20} />
                    </div>

                    <div className="stat-card-content">
                        <span>Remaining</span>

                        <strong>
                            ₹{remaining.toFixed(2)}
                        </strong>

                        <small>
                            Budget minus spending
                        </small>
                    </div>
                </div>

                {/* Expenses */}
                <div className="stat-card">
                    <div className="stat-card-icon">
                        <Receipt size={20} />
                    </div>

                    <div className="stat-card-content">
                        <span>Expenses</span>

                        <strong>
                            {expenses.length}
                        </strong>

                        <small>
                            Recorded transactions
                        </small>
                    </div>
                </div>

            </div>

            {/* Charts */}
            <div className="dashboard-chart-grid">

                {/* Spending by Category */}
                <div className="dashboard-card dashboard-chart-card">

                    <div className="dashboard-card-header">
                        <div>
                            <h3>
                                Spending by Category
                            </h3>

                            <p>
                                Where your money goes
                            </p>
                        </div>
                    </div>

                    {categoryData.length === 0 ? (
                        <div className="dashboard-empty">

                            <div className="dashboard-empty-icon">
                                ₹
                            </div>

                            <h3>
                                No spending data
                            </h3>

                            <p>
                                Add an expense to see
                                your category breakdown.
                            </p>

                            <Link
                                to="/expenses"
                                className="dashboard-empty-link"
                            >
                                Add your first expense
                                <ArrowRight size={16} />
                            </Link>

                        </div>
                    ) : (
                        <div className="dashboard-chart">

                            <ResponsiveContainer>
                                <BarChart
                                    data={categoryData}
                                >
                                    <CartesianGrid
                                        strokeDasharray="3 3"
                                    />

                                    <XAxis
                                        dataKey="name"
                                    />

                                    <YAxis />

                                    <Tooltip
                                        formatter={(value) =>
                                            `₹${Number(
                                                value
                                            ).toFixed(2)}`
                                        }
                                    />

                                    <Bar
                                        dataKey="amount"
                                        fill="#111111"
                                        radius={[
                                            4,
                                            4,
                                            0,
                                            0,
                                        ]}
                                    />
                                </BarChart>
                            </ResponsiveContainer>

                        </div>
                    )}

                </div>

                {/* Monthly Spending */}
                <div className="dashboard-card dashboard-chart-card">

                    <div className="dashboard-card-header">
                        <div>
                            <h3>
                                Monthly Spending
                            </h3>

                            <p>
                                Your spending trend
                            </p>
                        </div>
                    </div>

                    {monthlyData.length === 0 ? (
                        <div className="dashboard-empty">

                            <div className="dashboard-empty-icon">
                                <TrendingUp size={22} />
                            </div>

                            <h3>
                                No spending data
                            </h3>

                            <p>
                                Add expenses to see
                                your monthly spending trend.
                            </p>

                            <Link
                                to="/expenses"
                                className="dashboard-empty-link"
                            >
                                Add your first expense
                                <ArrowRight size={16} />
                            </Link>

                        </div>
                    ) : (
                        <div className="dashboard-chart">

                            <ResponsiveContainer>
                                <LineChart
                                    data={monthlyData}
                                >
                                    <CartesianGrid
                                        strokeDasharray="3 3"
                                    />

                                    <XAxis
                                        dataKey="month"
                                    />

                                    <YAxis />

                                    <Tooltip
                                        formatter={(value) =>
                                            `₹${Number(
                                                value
                                            ).toFixed(2)}`
                                        }
                                    />

                                    <Line
                                        type="monotone"
                                        dataKey="amount"
                                        stroke="#111111"
                                        strokeWidth={3}
                                        dot={{
                                            r: 4,
                                        }}
                                    />
                                </LineChart>
                            </ResponsiveContainer>

                        </div>
                    )}

                </div>

            </div>

            {/* Recent Expenses */}
            <div className="dashboard-card dashboard-recent-card">

                <div className="dashboard-card-header">

                    <div>
                        <h3>
                            Recent Expenses
                        </h3>

                        <p>
                            Your latest transactions
                        </p>
                    </div>

                    {expenses.length > 0 && (
                        <Link
                            to="/expenses"
                            className="dashboard-view-link"
                        >
                            View all
                            <ArrowRight size={16} />
                        </Link>
                    )}

                </div>

                {recentExpenses.length === 0 ? (
                    <div className="dashboard-empty dashboard-recent-empty">

                        <div className="dashboard-empty-icon">
                            <Receipt size={22} />
                        </div>

                        <h3>
                            No expenses yet
                        </h3>

                        <p>
                            Your latest expenses will
                            appear here.
                        </p>

                        <Link
                            to="/expenses"
                            className="dashboard-empty-link"
                        >
                            Add your first expense
                            <ArrowRight size={16} />
                        </Link>

                    </div>
                ) : (
                    <div className="table-container">

                        <table>

                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category</th>
                                <th>Date</th>
                                <th>Amount</th>
                            </tr>
                            </thead>

                            <tbody>

                            {recentExpenses.map(
                                (expense) => (
                                    <tr
                                        key={
                                            expense.id
                                        }
                                    >
                                        <td>
                                            #
                                            {
                                                expense.id
                                            }
                                        </td>

                                        <td>
                                            {expense
                                                    .category
                                                    ?.name ||
                                                "Uncategorized"}
                                        </td>

                                        <td>
                                            {
                                                expense.date
                                            }
                                        </td>

                                        <td>
                                            ₹
                                            {Number(
                                                expense.amount ||
                                                0
                                            ).toFixed(2)}
                                        </td>
                                    </tr>
                                )
                            )}

                            </tbody>

                        </table>

                    </div>
                )}

            </div>

        </div>
    );
}

export default Dashboard;